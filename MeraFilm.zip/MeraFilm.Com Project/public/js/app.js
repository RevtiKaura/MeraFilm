'use strict';

var angular = require('angular');
require('angular-route');

var app = angular.module('theatreApp', ['ngRoute','angular.filter']);

require('./controller');// as app.js and controller are in same level(same parent)
require('./service');

app.config(function($routeProvider){
  $routeProvider.when('/',{                   //when localhost:8000
    templateUrl: 'views/home.html',
    controller: 'HomeController',
    access: {restricted: false}
}).when('/admin', {
  templateUrl: 'views/admin.html',
  controller: 'AdminController',
  access: {restricted: true}
}).when('/bookingProceed', {
  templateUrl: 'views/bookingProceed.html',
  controller: 'BookingController',
  access: {restricted: false}
}).when('/seats', {
  templateUrl: 'views/seats.html',
  controller: 'SeatsController',
  access: {restricted: false}
}).when('/payment', {
  templateUrl: 'views/payment.html',
  controller: 'PaymentController',
}).when('/confirmation', {
  templateUrl: 'views/confirmation.html',
  controller: 'ConfirmationController',
}).when('/ratingProceed', {
  templateUrl: 'views/ratingProceed.html',
  controller: 'RatingController',
}).otherwise({
  redirectTo: '/',
});
});

app.run(function ($rootScope, $location, $route, AuthService) {
  $rootScope.$on('$routeChangeStart',
    function (event, next, current) {
      AuthService.getUserStatus()
      .then(function(){
        if (next.access.restricted && !AuthService.isLoggedIn()){
            $location.path('/');
            $('#signupmodal').modal('show');
          $route.reload();
        }
      });
  });
});
