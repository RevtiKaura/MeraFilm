'use strict';
module.exports = function($scope, $http,$rootScope,$location){

  var init = function(){
      $http.get('/api/theatres').success(function (response) {
        $scope.theatreData=response;
      });
  };
  init();//on load call

$scope.addTheatre=function(){
  $http.post('/api/addTheatre', $scope.theatre).success(function (response) { //we'll give the url one over here
  });
  alert("Theatre added Successfully!");
  init();
  $scope.theatre='';
};

$scope.deleteTheatre = function(theatre){
//  $scope.MovieInfoDetail=[];
  var x=confirm("Are you sure you want to delete ?");
  if(x){
    $http.get('/newapi/FindAllMovies/'+theatre.city+'/'+theatre.name).success(function (response) {
      $scope.MovieInfoDetail=response;
        if(response.length!=0)
      {
        alert("Movies are running in this theatre!!!");
        var y=confirm("Are you sure you want to continue ?");
        if(y){
        $http.delete('/api/deleteTheatre/'+theatre._id).success(function (response) {
        });
      }
      // var inf=  $scope.MovieInfoDetail.City;
      // alert(inf);

          // $http.delete('/newapi/deleteAllMovies/'+$scope.MovieInfoDetail.City+'/'+$scope.MovieInfoDetail.Theatre).success(function (response) {
          // });
          // var val='true';
          // if($scope.MovieInfoDetail.Title)
          // {
          //    $http.put('/myapi/updateMovie/'+map.Title+'/'+val).success(function(response){
          //    });
          // }
          // else
          // {
          //   val='false';
          //   $http.put('/myapi/updateMovie/'+map.Title+'/'+val).success(function(response){
          //   });
          // }
    }
    else{
      $http.delete('/api/deleteTheatre/'+theatre._id).success(function (response) {
      });
    }
  });
}
    init();
    location.reload();
};

var initmovie = function(){
    $http.get('/myapi/getMovie').success(function (response) {
      $scope.movieData=response;
    });
};
initmovie();//on load call

$scope.searchMovie= function(){
    $http.get('http://www.omdbapi.com/?t='+$scope.movie.Title+'&y='+$scope.movie.Year+'').success(function (response) {
      $scope.movieSearch=response;
      if(!$scope.movieSearch.Title)
      {
        alert("No Movie found!");
      }
    });
};

$scope.searchImdbMovie= function(){
    $http.get('http://www.omdbapi.com/?i='+$scope.imdb+'').success(function (response) {
      $scope.movieSearch=response;
      if(!$scope.movieSearch.imdbID)
      {
        alert("No Movie found!");
      }
    });
};

// $scope.addMovie=function(){
//   $http.get('/myapi/getExistingMovie/'+$scope.movieSearch.Title+'/'+$scope.movieSearch.Year).success(function (response) {
//     $scope.movieExist=response;
//     if(response.length!=0)
//     {
//       alert("Movie already exists in database!");
//     }
//     else {
//       $http.post('/myapi/addMovies', $scope.movieSearch).success(function (response) { //we'll give the url one over here
//       });
//       alert("Movie added Successfully!");
//
//     }
//   });
// //  $scope.movie='';
//     $("#movPoster").remove();
//     document.getElementById("detailId").reset();
//     location.reload();
// };
$scope.addMovie=function(){
  $http.get('/myapi/getExistingMovie/'+$scope.movieSearch.Title+'/'+$scope.movieSearch.Year).success(function (response) {
      $scope.movieExist=response;
      if(response.length!=0)
        {
             alert("Movie already exists in database!");
        }
        else{
  $http.post('/myapi/addMovies', $scope.movieSearch).success(function (response) { //we'll give the url one over here
  });
  alert("Movie added Successfully!");
  }
  $scope.movieSearch='';
    $("#movPoster").remove();
    document.getElementById("detailId").reset();
    self.location.reload();

});
};
$scope.removeMovie = function(movie){
  var x=confirm("Are you sure you want to remove ?");
  if(x){
    $http.delete('/myapi/deleteMovie/'+movie._id).success(function (response) {
  });
  $http.delete('/newapi/removeMovieMapping/'+movie.Title).success(function (response) {
  });
  alert("Movie is removed from theatres!");
  }
  initmovie();
  location.reload();
};

var initmapping = function(){
    $http.get('http://localhost:8000/myapi/getMovie').success(function (response) {
      $scope.MovieList=response;
    });
    $http.get('http://localhost:8000/api/theatres').success(function (response) {
      $scope.TheatreDetails=response;
    });
};

initmapping();//on load call

var initremove = function(){
    $http.get('http://localhost:8000/myapi/getMovie').success(function (response) {
      $scope.MovieList=response;
    });
    $http.get('http://localhost:8000/api/theatres').success(function (response) {
      $scope.TheatreDetails=response;
    });
    $http.get('/newapi/showMovieTheatre').success(function (response) {
      $scope.AllMovies=response;
    });

};

initremove();//on load call

$scope.deleteMovieMap = function(map){
  var x=confirm("Are you sure you want to remove?");
    if(x){
        $http.delete('/newapi/removeMovieMap/'+map._id).success(function (response) {
        });
        alert("Movie is removed from theatre!");
        $http.get('/newapi/selmoviename/'+map.Title).success(function (response) {
      //  alert(response.length);
          if(response.length==0)
          {
            //alert("turn false");
            var val='false';
            $http.put('/myapi/updateMovie/'+map.Title+'/'+val).success(function(response){

          });
          }
        });
      };

      initremove();
      self.location.reload();
  };

$(document).ready(function() {
  $("#btn1").click(function () {
    var text=($("#hour").val())+" : "+($("#min").val())+" "+($("#format").val());
    $('#res').append("<option value='"+text+"'>"+text+"</option>");
   });
 });

 $(document).ready(function(){
   $("#datepicker").datepicker({dateFormat:'dd, M yy'});
 });

$scope.insertMapping=function(){
    var arr=[];
    var length=$('#res').children('option').length;
    for(var i=0;i<length;i++)
    {
      arr[i]=$('#res option').eq(i).val();
    }
    $scope.mapping.ShowTimings=arr;
      $scope.mapping.Date=$('#datepicker').val();
    $http.post('/newapi/newMapping',$scope.mapping).success(function (response) {
     });
     var val='true';
     $http.put('/myapi/updateMovie/'+ $scope.mapping.Title+'/'+val).success(function (response) {
            console.log(response);
          });
      $scope.mapping='';
      alert("Movie mapped to theatre successfully!");
      document.getElementById("formid").reset();
        $("#res").remove();
        location.reload();
  };

var initreview = function(){
    $http.get('/myapi/getMovie').success(function (response) {
      $scope.movieData=response;
    });
    $http.get('/revapi/reviews').success(function (response) {
      $scope.reviewMovies=response;
    });
};

initreview();//on load call

$scope.deleteReview = function(review){
  var x=confirm("Are you sure you want to delete ?");
  if(x){
    $http.delete('/revapi/deleteReview/'+review._id).success(function (response) {
  });
  }
  initreview();
};

  $(document).ready(function() {
      $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
          e.preventDefault();
          $(this).siblings('a.active').removeClass("active");
          $(this).addClass("active");
          var index = $(this).index();
          $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
          $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
      });
  });

};
