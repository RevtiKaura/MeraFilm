module.exports = function($scope, $http,$rootScope,$location){

  var init = function(){
    var inf=$rootScope.vary;
  $http.get('/newapi/selmoviename/'+inf).success(function (response) {
        $rootScope.selectedMovie=response;

      });
      $http.get('http://localhost:8000/api/theatres').success(function (response) {
        $scope.TheatreDetails=response;
      });
      $http.get('/myapi/moviePoster/'+inf).success(function (response) {
        $rootScope.moviedata=response;
      });
  };
  init();


        $scope.setShow=function(m,n,d,c){
          $rootScope.SelectedTime=m;
          $rootScope.SelectedTheatre=n;
          $rootScope.SelectedDate=d;
          $rootScope.SelectedCity=c;
          $location.path('/seats');

        };
$scope.movDates=[];
var showDates=function() {
for(i=0;i<4;i++)
{
  var date=new Date();
  date.setDate(date.getDate()+i);
  $scope.movDates[i]=date;
  // $scope.movDates[i].toString();
}
};
showDates();


};
