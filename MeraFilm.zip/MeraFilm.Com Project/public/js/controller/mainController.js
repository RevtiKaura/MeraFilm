'use strict';

module.exports = function ($scope, $q, $location, AuthService) {

    $scope.login = function () {

      // initial values
      $scope.error = false;
      $scope.disabled = true;
      $scope.checked=false;

      // call login from service
      AuthService.login($scope.loginForm.username, $scope.loginForm.password, $q)
        // handle success
        .then(function () {
          $('#signupmodal').modal('hide');
          $location.path('/admin');
          $scope.disabled = false;
          $scope.checked=true;
          $scope.loginForm = {};
        })
        // handle error
        .catch(function () {
          $scope.error = true;
          $scope.errorMessage = "Invalid username and/or password";
          $scope.disabled = false;
          $scope.loginForm = {};
        });

    };

    $scope.logout = function () {

        // call logout from service
        AuthService.logout($q)
          .then(function () {
            $location.path('/login');
            $scope.checked=false;
          });

      };

      $scope.register = function () {

  // initial values
  $scope.error = false;
  $scope.disabled = true;

  // call register from service
  AuthService.register($scope.registerForm.username, $scope.registerForm.password, $q)
    // handle success
    .then(function () {
     $('#mytabs a[href="#login"]').tab('show');
      $scope.disabled = false;
      $scope.registerForm = {};
    })
    // handle error
    .catch(function () {
      $scope.error = true;
      $scope.errorMessage = "Something went wrong!";
      $scope.disabled = false;
      $scope.registerForm = {};
    });

};


}
