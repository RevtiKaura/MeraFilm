module.exports = function($scope, $http,$rootScope,$location)
{
    var init = function(){
      var m=$rootScope.vary;
      var tm=$rootScope.SelectedTime;
      var c=$rootScope.SelectedCity;
      var t=$rootScope.SelectedTheatre;
      var d=$rootScope.SelectedDate;

      $http.get('/conapi/getBlockedSeats/'+m+'/'+c+'/'+t+'/'+tm).success(function (response) {
          //  $rootScope.occupiedSeats=response;
          for(i=0;i<response.length;i++){
            for(j=0;j<response[i].SeatNo.length;j++)
            {
              $('#'+response[i].SeatNo[j]).addClass('red');
            }
          }
          });
    };
init();



$(document).ready(function(){
  $('#Seatclass').change(function(){
    var sel=$('#Seatclass').find(":selected").text();
    if(sel=="GOLD")
    {
    $('#silver tr>td>div').addClass('grey');
    $('#gold tr>td>div').removeClass('grey');
    }
    if(sel=="SILVER")
    {
      $('#gold tr>td>div').addClass('grey');
      $('#silver tr>td>div').removeClass('grey');
    }

  $('#noofseats').change(function(){
    var no = $('#noofseats').find(":selected").text();
    document.getElementById("sno").innerHTML= no;
    var countdiv=[];


  $('.style1').click(function(){
  if(!$(this).hasClass('grey')||$(this).hasClass('red'))
  {
//alert($(this).hasClass('grey'));
    if(countdiv.length < no)
    {

      $(this).toggleClass("green");
      var id=$(this).attr('id');
      var cn=$(this).hasClass('green');

      if(cn)
          {   countdiv.push(id);
              $rootScope.SeatNumbers=JSON.stringify(countdiv);
              document.getElementById("seatno").innerHTML=countdiv;
          }
      else{
            var ind=countdiv.indexOf(id);
            countdiv.splice(ind,1);
            $rootScope.SeatNumbers=JSON.stringify(countdiv);
          }
        if(sel== "SILVER")
        {
          document.getElementById("amount").innerHTML=countdiv.length*200;
        }
        else
        {
          document.getElementById("amount").innerHTML=countdiv.length*280;
        }

    }
    else {

      var id=$(this).attr('id');

      if(countdiv.indexOf(id) == -1 )
        alert("Request you to  book only " + no +" seats");
      else {
        countdiv.splice(countdiv.indexOf(id),1);
        console.log( countdiv );
        $rootScope.movieSeats=JSON.stringify(countdiv);
          sessionStorage.setItem('movieSeats',$rootScope.movieSeats);
          document.getElementById("seatno").innerHTML=countdiv;
        $(this).removeClass("green");
        $(this).addClass("style1");
      }
  }
}
});


});
});

});

$scope.Payment=function(){
  $rootScope.FinalAmount=  document.getElementById("amount").innerHTML;
  $rootScope.SeatNumbers1=  document.getElementById("seatno").innerHTML;
  $rootScope.Quantity=  document.getElementById("sno").innerHTML;
  var seatnum=parseInt(document.getElementById("sno").innerHTML);
  var count=0;
    $('.green').each(function(){
      count++;
    });
    if(count==seatnum)
    {
  $location.path('/payment');
    }
    else
  {
    alert("Please select the specified number of seats!!")
  }
};

};
