
var app = require('angular').module('theatreApp');
app.controller('HomeController', require('./homeController'));
app.controller('BookingController', require('./bookingController'));
app.controller('SeatsController', require('./seatsController'));
app.controller('PaymentController', require('./paymentController'));
app.controller('ConfirmationController', require('./confirmationController'));
app.controller('RatingController', require('./ratingController'));
app.controller('AdminController', require('./adminController'));
app.controller('MainController', require('./mainController'));
