module.exports = function($scope, $http,$rootScope,$location){


  $scope.confirm=function(){
  $rootScope.cess=$rootScope.FinalAmount*0.15;
  $rootScope.res=parseInt($rootScope.cess)+parseInt($rootScope.FinalAmount);
  $rootScope.movieEmail=document.getElementById("emailid").value;
  $rootScope.moviePhone=document.getElementById("phoneid").value;

    var m=$rootScope.vary;
    var tm=$rootScope.SelectedTime;
    var c=$rootScope.SelectedCity;
    var t=$rootScope.SelectedTheatre;
    var d=$rootScope.SelectedDate;
    var se=$rootScope.Quantity;
    var sn=$rootScope.SeatNumbers;
    var am=$rootScope.res;
    var e=$rootScope.movieEmail;
    var p=$rootScope.moviePhone;


    $http.post('/conapi/newTicket/'+m+'/'+c+'/'+d+'/'+t+'/'+tm+'/'+sn+'/'+se+'/'+am+'/'+e+'/'+p).success(function (response)
    {
    });
      $location.path('/confirmation');
  };
};
