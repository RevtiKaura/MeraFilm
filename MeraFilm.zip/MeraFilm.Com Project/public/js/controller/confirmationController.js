module.exports = function($scope, $http,$rootScope,$location){

}
