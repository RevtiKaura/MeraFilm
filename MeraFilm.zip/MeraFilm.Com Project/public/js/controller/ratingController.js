module.exports = function($scope, $http,$rootScope,$location){
  var initrating = function(){
    var mov=$rootScope.MovieTitle;
        $http.get('/revapi/selname/'+mov).success(function (response) {
          $rootScope.reviewDataDetails=response;
          $rootScope.sum =0;
          for(i=0;i<$rootScope.reviewDataDetails.length;i++)
          {
         $rootScope.sum +=parseInt($rootScope.reviewDataDetails[i].Rating);
          }

          $rootScope.count =0;
          for(i=0;i<$rootScope.reviewDataDetails.length;i++)
          {
         $rootScope.count++;
          }

        });

        $http.get('/revapi/reviews').success(function (response) {
          $rootScope.reviewData=response;


        });

        $http.get('/myapi/moviePoster/'+mov).success(function (response) {
        $rootScope.movieRate=response;
      });

  };
  initrating();

$scope.myReview=function(){
  $rootScope.reviewTitle=document.getElementById("reviewTitle").value;
  $rootScope.reviewComment=document.getElementById("reviewComment").value;
  $rootScope.reviewMovie=document.getElementById("pid").innerHTML;
    var radios = document.getElementsByName('star');

  for (var i = 0, length = radios.length; i < length; i++) {
      if (radios[i].checked) {
          // do whatever you want with the checked radio
        //  alert(radios[i].value);
          $rootScope.ratingValue=radios[i].value;
          // only one radio can be logically checked, don't check the rest
          break;
      }
  }

};

  $scope.mySubmit=function(){
    $scope.reviewName=document.getElementById("reviewer_name").value;
    $scope.reviewPhone=document.getElementById("phone_id").value;
    $scope.reviewEmail=document.getElementById("email_id").value;
    var n=$scope.reviewName;
    var p=$scope.reviewPhone;
    var e=$scope.reviewEmail;
    var t=$scope.reviewTitle;
    var c=$scope.reviewComment;
    var v=$scope.ratingValue;
    var m=$scope.reviewMovie;

    $http.post('/revapi/newReview/'+m+'/'+v+'/'+t+'/'+c+'/'+n+'/'+e+'/'+p).success(function (response)
    {
    });
      alert("Review added Successfully!");
      $scope.formName2.$setPristine();
      $scope.formName1.$setPristine();
      $scope.formName1.$setUntouched();
      $scope.formName2.$setUntouched();

      document.getElementById("form_id").reset();
      document.getElementById("form_modal").reset();
       $('#myFormModal').modal('hide');
      initrating();
    //  self.location.reload();


  };


};
