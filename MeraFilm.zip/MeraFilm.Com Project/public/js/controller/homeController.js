module.exports = function($scope, $http,$rootScope,$location){

  var init = function(){
      $http.get('/myapi/getMovie').success(function (response) {
        $scope.movieData=response;
      });
  };
  init();

$scope.bookMovie = function(m){
    $rootScope.vary=m;
    $location.path('/bookingProceed');
    };

    $scope.rating = function(m){
        $rootScope.MovieTitle=m;
        $location.path('/ratingProceed');
        };
 


};
