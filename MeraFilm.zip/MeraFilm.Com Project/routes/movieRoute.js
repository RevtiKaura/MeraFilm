var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MovieBooking');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to MovieDB");
});

var MovieSchema = mongoose.Schema({
  Title: String,
  Year: String,
  Runtime:String,
  Genre:String,
  Director:String,
  Actors:String,
  Language:String,
  Poster:String,
  status:String,
  imdbRating:String

});

var Movie = mongoose.model('Movie',MovieSchema,'Movie');


router.post('/addMovies', function (req, res) {
  var movie = new Movie({
    Title: req.body.Title,
    Year: req.body.Year,
    Runtime: req.body.Runtime,
    Genre: req.body.Genre,
    Director: req.body.Director,
    Actors: req.body.Actors,
    Language: req.body.Language,
    Poster: req.body.Poster,
    imdbRating: req.body.imdbRating,
    status:"false"
  });
  movie.save(function(err,docs){
    console.log('Movie Saved Successfully'+docs);
  });
});


router.get('/getMovie', function (req, res) {
    Movie.find({}, function (err, docs) {
    res.json(docs);
    });
});

router.get('/getExistingMovie/:title/:year', function (req, res) {
    Movie.find({Title:req.params.title,Year:req.params.year}, function (err, docs) {
    res.json(docs);
  //  console.log(docs);
    });
});

router.delete('/deleteMovie/:id',function(req, res){
  Movie.remove({_id:req.params.id},function(err, docs){
    console.log('Movie Removed Successfully');
  });
});

router.put('/updateMovie/:Title/:val', function(req, res){

    Movie.findOneAndUpdate({Title:req.params.Title},
      {
        $set:{status:req.params.val}
      }, function (err, data) {
      res.json(data);
    });
});

router.get('/moviePoster/:t',function(req,res){
  Movie.find({Title:req.params.t},function(err,docs){
    res.json(docs);
  });
});


module.exports = router;
