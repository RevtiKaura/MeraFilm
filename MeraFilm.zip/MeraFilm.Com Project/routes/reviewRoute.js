var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MovieBooking');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
console.log("Connected to ReviewDB");
});


var ReviewSchema = mongoose.Schema({
    ReviewMovieTitle:String,
    Rating : String,
    ReviewTitle : String,
    Comment: String,
    Name : String,
    Email : String,
    Phone : String,
});

var Review = mongoose.model('Review',ReviewSchema,'Review');

router.post('/newReview/:MovieRateTitle/:Rating/:reviewtitle/:comment/:name/:email/:phone', function (req, res) {
  var review = new Review({
    ReviewMovieTitle:req.params.MovieRateTitle,
    Rating: req.params.Rating,
    ReviewTitle: req.params.reviewtitle,
    Comment: req.params.comment,
    Name: req.params.name,
    Email: req.params.email,
    Phone: req.params.phone
  });
  review.save(function(err,docs){
    console.log('Review Saved Successfully'+docs);
  });
});

router.route('/selname/:m').get(function (req, res) {
Review.find({ReviewMovieTitle:req.params.m},function(err,docs){
  if(err)
  {
    return res.send(err);

  }
    res.json(docs);
});
});

router.get('/reviews', function (req, res) {// it should be same as in mainController.js
    Review.find({}, function (err, docs) {// var Theatre reference is used
    res.json(docs);
    });
});

router.delete('/deleteReview/:id',function(req, res){
  Review.remove({_id:req.params.id},function(err, docs){
    console.log('Review Removed Successfully');
  });
});

module.exports = router;
