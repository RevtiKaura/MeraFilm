var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var moment = require('moment');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MovieBooking');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to MappingDB");
});

var MappingSchema = mongoose.Schema({
  Title: String,
  City: String,
  Theatre:String,
  Date:String,
  ShowTimings:Array
  });

var Mapping = mongoose.model('Mapping',MappingSchema,'Mapping');

router.post('/newMapping', function (req, res) {
  var mapping = new Mapping({
    Title: req.body.Title,
    City: req.body.City,
    Theatre: req.body.Theatre,
    Date: req.body.Date,
    ShowTimings: req.body.ShowTimings
  });
  mapping.save(function(err,docs){
    console.log('Mapping Saved Successfully'+docs);
  });
});

router.get('/showMovieTheatre', function (req, res) {
    Mapping.find({}, function (err, docs) {
    res.json(docs);
    });
});

router.get('/FindAllMovies/:city/:theatre', function (req, res) {
    Mapping.find({City:req.params.city,Theatre:req.params.theatre}, function (err, docs) {
      if(err)
      {
        return res.send(err);
      }
      res.send(docs);
    //console.log(docs);
    });
    });

router.route('/selmoviename/:m').get(function (req, res) {
Mapping.find({Title:req.params.m},function(err,Data){
  if(err)
  {
    return res.send(err);
  }
  res.send(Data);
});
});

router.delete('/removeMovieMap/:id',function(req, res){
  Mapping.remove({_id:req.params.id},function(err, docs){
    console.log('Mapped Movie Removed Successfully');
  });
});

router.delete('/removeMovieMapping/:m',function(req, res){
  Mapping.remove({Title:req.params.m},function(err, docs){
    console.log('Mapped Movie Removed Successfully from title');
  });
});

// router.delete('/deleteAllMovies/:city/:t',function(req, res){
//   Mapping.remove({City:req.params.city,Theatre:req.params.t}, function (err, docs) {
//     //console.log(docs[0].City);
//       console.log('Movies Removed from theatre Successfully!!!!');
//   });
// });

module.exports = router;
