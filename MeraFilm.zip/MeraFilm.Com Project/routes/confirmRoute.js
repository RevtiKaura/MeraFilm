var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MovieBooking');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to BookingDB");
});


var BookingSchema = mongoose.Schema({
    Title : String,
    City : String,
    Date: String,
    Theatre : String,
    Show : String,
    SeatNo : Array,
    Quantity : String,
    Amount : String,
    Email : String,
    Phone : String,
});

var Booking = mongoose.model('Booking',BookingSchema, 'Booking');

router.post('/newTicket/:title/:city/:date/:theatre/:showtime/:sno/:seatquantity/:amount/:email/:phone', function (req, res) {
  var booking = new Booking({
    Title: req.params.title,
    City: req.params.city,
    Date:req.params.date,
    Theatre: req.params.theatre,
    Show: req.params.showtime,
    SeatNo: JSON.parse(req.params.sno),
    Quantity: req.params.seatquantity,
    Amount: req.params.amount,
    Email: req.params.email,
    Phone: req.params.phone
  });
  booking.save(function(err,docs){
    console.log('Booking Saved Successfully'+docs);
  });
});

router.get('/getBlockedSeats/:title/:city/:theatre/:showtime', function (req, res) {
    Booking.find({Title:req.params.title,City:req.params.city,Theatre:req.params.theatre,Show:req.params.showtime}, function (err, docs) {
    res.json(docs);
    // console.log(docs[0].SeatNo);
    });
});

module.exports = router;
